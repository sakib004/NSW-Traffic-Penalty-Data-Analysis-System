import sys
import datetime
import time

from main import Ui_MainWindow

from PyQt5.QtWidgets import QApplication, QMainWindow, QFileDialog, QMessageBox
from PyQt5.QtCore import QAbstractTableModel, Qt
# Numpy
import numpy as np
# Matplotlib
import matplotlib
matplotlib.use("Qt5Agg")
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt

from base import *
from core import *


class MyMatplotlibFigure(FigureCanvas):
    """
    This is a class to create a figure to show in the GUI by using Matplotlib
    """
    def __init__(self, width=10, height=10, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi, tight_layout=True)

        super(MyMatplotlibFigure, self).__init__(self.fig)
        self.axes = self.fig.add_subplot(111)

    def mat_plot_draw_scatter(self, df):
        """
        This is a function to draw a scatter diagram by using Matplotlib
        :param: df <DataFrame>
        :return: none
        """
        self.axes.cla()
        # self.axes.spines['top'].set_visible(False)
        # self.axes.spines['right'].set_visible(False)
        # self.axes.spines['bottom'].set_position(('data', 0))
        # self.axes.spines['left'].set_position(('data', 0))

        # random colors for each offence code
        colors = np.random.rand(df['OFFENCE_CODE'].count())
        # set a scatter diagram
        self.axes.scatter(df['OFFENCE_CODE'], df['TOTAL_NUMBER'], c=colors, alpha=0.7)
        # set X axis label
        self.axes.set_xlabel('OFFENCE_CODE')
        # set Y axis label
        self.axes.set_ylabel('TOTAL_NUMBER')
        # set title of the scatter diagram
        self.axes.set_title('The distribution of cases in each offence code')

        self.fig.canvas.draw()
        self.fig.canvas.flush_events()

    def mat_plot_draw_bar(self, df):
        """
        This is a function to draw a bar chart by using Matplotlib
        :param: df <DataFrame>
        :return: none
        """
        self.axes.cla()
        # self.axes.spines['top'].set_visible(False)
        # self.axes.spines['right'].set_visible(False)
        # self.axes.spines['bottom'].set_position(('data', 0))
        # self.axes.spines['left'].set_position(('data', 0))

        # columns <==> rows
        code = pd.DataFrame(df.values.T, columns=df.index, index=df.columns)
        # covert to a list
        nmpNum = code.iloc[2].to_numpy()
        nmmpId = np.arange(1, len(nmpNum) + 1)

        # set a bar chart
        self.axes.bar(nmmpId, nmpNum, color='green', alpha=0.7)
        # set X axis label
        self.axes.set_xlabel('OFFENCE_CODE')
        # set Y axis label
        self.axes.set_ylabel('TOTAL_NUMBER')
        # set title of the bar chart diagram
        self.axes.set_title('The number of cases captured by radar or camera')

        self.fig.canvas.draw()
        self.fig.canvas.flush_events()

    def mat_plot_draw_line(self, listDf):
        """
        This is a function to draw a line chart by using Matplotlib
        :param: df <DataFrame>
        :return: none
        """
        self.axes.cla()
        # self.axes.spines['top'].set_visible(False)
        # self.axes.spines['right'].set_visible(False)
        # self.axes.spines['bottom'].set_position(('data', 0))
        # self.axes.spines['left'].set_position(('data', 0))

        for df in listDf:
            # set a line chart
            self.axes.plot(df['OFFENCE_MONTH'], df['TOTAL_NUMBER'])

        # set X axis label
        self.axes.set_xlabel('OFFENCE_MONTH')
        # set Y axis label
        self.axes.set_ylabel('TOTAL_NUMBER')
        # set title of the line chart diagram
        self.axes.set_title('The trend of offence cases related to mobile phone over the period')

        self.fig.canvas.draw()
        self.fig.canvas.flush_events()

class pandasModel(QAbstractTableModel):
    """
    This is a class to display pandas dataframe into the QTableView
    """
    def __init__(self, data):
        QAbstractTableModel.__init__(self)
        self._data = data

    def rowCount(self, parent=None):
        return self._data.shape[0]

    def columnCount(self, parnet=None):
        return self._data.shape[1]

    def data(self, index, role=Qt.DisplayRole):
        if index.isValid():
            if role == Qt.DisplayRole:
                return str(self._data.iloc[index.row(), index.column()])
        return None

    def headerData(self, col, orientation, role):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return self._data.columns[col]
        return None

class MyMainWindow (QMainWindow,Ui_MainWindow):

    def __init__(self):
        super(MyMainWindow, self).__init__()
        self.setupUi(self)
        # menu
        self.actionData_Analysis.triggered.connect(self.showDataAnalysis)
        self.actionHome.triggered.connect(self.showHome)
        self.actionNew_Dataset.triggered.connect(self.openNewFile)
        self.actionRevert.triggered.connect(self.reset)
        self.actionQuit.triggered.connect(self.quit)
        self.actionAbout_NSW_Software.triggered.connect(self.about)

        # Common search
        self.search_PushButton.clicked.connect(self.search)

        # Offence Code
        self.drillOC_PushButton.clicked.connect(self.drillDownByOffenceCode)
        self.detailOC_PushButton.clicked.connect(self.showDetailOC)
        self.compareOC_PushButton.clicked.connect(self.clickOCCompare)

        # Radar/Camera
        self.drillRC_PushButton.clicked.connect(self.drillDownByRadarCamera)
        self.detailRC_PushButton.clicked.connect(self.showDetailRC)
        self.compareRC_PushButton.clicked.connect(self.clickRCCompare)

        # Mobile phone
        self.drillMP_PushButton.clicked.connect(self.drillDownByMobilePhone)
        self.detailMP_PushButton.clicked.connect(self.showDetailMP)
        self.compareMP_PushButton.clicked.connect(self.clickMPCompare)

        self.analysis_Widget.hide()
        self.welcome_Widget.show()

        # Load system configuration
        self._iniDict = {}
        self._iniDict = initiate()

        self._compareAData = None
        self._compareBData = None
        self._compareADataType = ""
        self._compareBDataType = ""
        try:
            # Load data from the original data file (CSV)
            self.loadNewDataset(self._iniDict['OriginalFilePath'] + self._iniDict['OriginalFIleName'])
        except Exception as e:
            if (sys):
                sys.exit(0)

    def loadNewDataset(self, datasetFilePathName):
        try:
            # Load data from the original data file (CSV)
            self._originalDataframe = load_data(datasetFilePathName)

            # Get the max and min dates in order to set search time period value limits
            self._fromDate = self._originalDataframe['OFFENCE_MONTH'].min()
            self._toDate = self._originalDataframe['OFFENCE_MONTH'].max()

            # Convert datetime to str
            self._strStartDate = datetime.datetime.strftime(self._fromDate, '%d-%m-%Y')
            self._strEndDate = datetime.datetime.strftime(self._toDate, '%d-%m-%Y')

            # Set welcome page content
            self.welcomeIntro_Label.setText("The data period is from " + self._strStartDate + " to " + self._strEndDate + ".")

            # Set default start date and end date
            self.start_DateEdit.setDate(self._fromDate)
            self.end_DateEdit.setDate(self._toDate)

            # Set mobile phone offences in the combobox
            self._comboTexts = getMobilePhoneAllOffences(self._originalDataframe)
            self.mobile_ComboBox.clear()
            for text in self._comboTexts:
                self.mobile_ComboBox.addItem(text)
            self.mobile_ComboBox.setCurrentIndex(0)

        except Exception as e:
            print(e)
            if len(e.args) >= 2:
                msg_box = QMessageBox(QMessageBox.Warning, "Load the file failed.", str(e.args[1]))
            else:
                msg_box = QMessageBox(QMessageBox.Warning, "Load the file failed.", str(e.args[0]))
            msg_box.exec_()
            raise e

    def showHome(self):
        self.analysis_Widget.hide()
        self.welcome_Widget.show()

    def showDataAnalysis(self):
        self.welcome_Widget.hide()
        self.analysis_Widget.show()
        
    def openNewFile(self):
        file, ok = QFileDialog.getOpenFileName(self, "Open", "C:/", "CSV Files (*.csv)")
        # self.statusbar.showMessage(file)

        try:
            if ok:
                # Load data from the original data file (CSV)
                self.loadNewDataset(file)
                msg_box = QMessageBox(QMessageBox.Warning, "Load the file successfully.",
                                      "The new dataset has been loaded successfully.")
                msg_box.exec_()
        except Exception as e:
            print(e)

    def reset(self):
        try:
            # Load data from the original data file (CSV)
            self.loadNewDataset(self._iniDict['OriginalFilePath'] + self._iniDict['OriginalFIleName'])
            msg_box = QMessageBox(QMessageBox.Warning, "Load the file successfully.",
                                  "The dataset has been reverted successfully.")
            msg_box.exec_()
        except Exception as e:
            print(e)

    def quit(self):
        if (sys):
            sys.exit(0)

    def about(self):
        content = ""
        content += "Software Info" + '\n' + '\n'
        content += "Software Name: " + self._iniDict['Name'] + '\n'
        content += "Description: " + self._iniDict['Description'] + '\n'
        content += "Software Version: " + self._iniDict['Version'] + '\n'
        content += "\n"
        content += "Contributors: " + self._iniDict['Developer']

        QMessageBox.about(self, "About", content)

    def search(self):
        try:
            time_start = time.time()

            # startDate, endDate should be from the user input in the user interface
            startDate = self.start_DateEdit.dateTime().toPyDateTime()
            endDate = self.end_DateEdit.dateTime().toPyDateTime()

            self._df = fetch_data_by_date(self._originalDataframe, startDate, endDate)

            model = pandasModel(self._df)
            self.baseData_TableView.setModel(model)

            # Set mobile phone offences in the combobox
            self._comboTexts = getMobilePhoneAllOffences(self._df)
            self.mobile_ComboBox.clear()
            for text in self._comboTexts:
                self.mobile_ComboBox.addItem(text)
            self.mobile_ComboBox.setCurrentIndex(0)

            time_end = time.time()

            if self._df.empty:
                self.statusbar.showMessage("No records found.")
            else:
                self.statusbar.showMessage("{} records found in {:.2f} seconds".format(self._df['OFFENCE_CODE'].count(), time_end - time_start))

        except Exception as e:
            # output the log file
            print(e)

    def drillDownByOffenceCode(self):
        """
        This is a drill down function by offence code
        """
        try:
            time_start = time.time()

            # initiate
            num = None
            order = False

            # get the user inputs - Checkbox
            listIndicators = self.getCheckBoxStates()

            # get the user inputs - fetch numbers by the total numbers of cases
            num = self.getRadioButtonStates()

            # get largest or smallest
            if self.smallest_RadioButton.isChecked():
                order = True
            if self.largest_RadioButton.isChecked():
                order = False

            # Format data for aggregation use
            self._dfOC = format_data_for_aggregation(self._df)

            # Filter data by indicators
            self._dfOC = filter_data_by_indicators(self._dfOC, listIndicators)

            # ________________________________________________________________________
            # Aggregate data group by offence code
            # For a user-selected period, produce a chart to show the distribution of cases in each offence code
            # ________________________________________________________________________
            self._dfOC = aggregate_data_group_by_offence_code(self._dfOC, order, num)

            if not hasattr(self, "canvasOC"):
                self.canvasOC = MyMatplotlibFigure(width=5, height=4, dpi=100)

            self.canvasOC.mat_plot_draw_scatter(self._dfOC)
            self.figureOC_HorizontalLayout.addWidget(self.canvasOC)

            time_end = time.time()

            if self._dfOC.empty:
                self.statusbar.showMessage("No records found.")
            else:
                self.statusbar.showMessage("{} records found in {:.2f} seconds".format(self._dfOC['OFFENCE_CODE'].count(), time_end - time_start))

        except Exception as e:
            # output the log file
            print(e)

    def getRadioButtonStates(self):

        if self.all_RadioButton.isChecked():
            num = None
        elif self.largest_RadioButton.isChecked():
            num = self.largest_SpinBox.value()
        elif self.smallest_RadioButton.isChecked():
            num = self.smallest_SpinBox.value()
        else:
            num = None

        return num

    def getCheckBoxStates(self):

        # store checkbox checked status
        listIndicators = []

        # seat belt checkbox
        if self.seatbelt_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        # speed checkbox
        if self.speed_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        # parking checkbox
        if self.parking_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        # school zone checkbox
        if self.school_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        # mobile phone checkbox
        if self.mobile_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        # food safety checkbox
        if self.food_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        # point to point camera checkbox
        if self.ptopC_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        # red light camera checkbox
        if self.redC_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        # speed camera checkbox
        if self.speedC_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        # criminal infringement notice scheme checkbox
        if self.criminal_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        # bicycle, wheeled toy and other non-Motor vehicle checkbox
        if self.bicycle_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        return listIndicators

    def showDetailOC(self):

        # ________________________________________________________________________
        # Scatter diagram to illustrate the distribution of cases in each offence code
        # X axis shows offence codes, while Y axis shows the total number of cases in each offence code
        # For a user-selected period, produce a chart to show the distribution of cases in each offence code
        # ________________________________________________________________________
        fig, ax = plt.subplots()
        # random colors for each offence code
        colors = np.random.rand(self._dfOC['OFFENCE_CODE'].count())
        # set a scatter diagram
        ax.scatter(self._dfOC['OFFENCE_CODE'], self._dfOC['TOTAL_NUMBER'], c=colors, alpha=0.7)
        # set X axis label
        ax.set_xlabel('OFFENCE_CODE')
        # set Y axis label
        ax.set_ylabel('TOTAL_NUMBER')
        # set title of the scatter diagram
        ax.set_title('The distribution of cases in each offence code')
        # adjust diagram position
        plt.subplots_adjust(top=0.8, bottom=0.2)

        # shows a detailed information for each record
        text = []
        for i in range(self._dfOC['OFFENCE_CODE'].count()):
            # a detailed information
            str_info = 'Offence Code: ' + str(self._dfOC['OFFENCE_CODE'][i]) + '\n'
            str_info += 'Offence Description: ' + str(self._dfOC['OFFENCE_DESC'][i]) + '\n'
            str_info += 'Number of Cases: ' + str(self._dfOC['TOTAL_NUMBER'][i])
            text.append(str_info)

        # draw points with a detailed information
        self.po_annotation = []
        for i in range(self._dfOC['OFFENCE_CODE'].count()):
            point_x = self._dfOC['OFFENCE_CODE'][i]
            point_y = self._dfOC['TOTAL_NUMBER'][i]
            point, = plt.plot(point_x, point_y, '.', c='green', alpha=0.0)
            # set x axis, y axis offset for a detailed information
            xoffset = -200
            yoffset = 40
            # a box contains detailed information
            bbox = dict(boxstyle='round', fc='lightgreen', alpha=0.6)
            # set arrow style
            arrowprops = dict(arrowstyle='->', connectionstyle='arc3,rad=0.')
            # set annotate
            annotation = plt.annotate(text[i], xy=(self._dfOC['OFFENCE_CODE'][i], self._dfOC['TOTAL_NUMBER'][i]),
                                         xytext=(xoffset, yoffset),
                                         textcoords='offset points', bbox=bbox, arrowprops=arrowprops, size=10)
            # set visible
            annotation.set_visible(False)
            self.po_annotation.append([point, annotation])

        # ax.grid(True)
        fig.tight_layout()
        # bind motion event to shows detailed information for a chosen record
        on_move_id = fig.canvas.mpl_connect('motion_notify_event', self.on_move)
        # show the scatter diagram
        plt.show()

    def drillDownByRadarCamera(self):
        """
        This is a drill down function by radar or camera
        """
        try:
            time_start = time.time()

            # initiate
            num = None
            order = False

            # get the user inputs - radar/camera radio button
            listRadarCamera = self.getRadarCameraRadioButtonKeyword()

            # get the user inputs - Checkbox
            listIndicators = self.getRadarCameraCheckBoxStates()

            # get the user inputs - Keywords
            listKey = self.getKeywordsForRadarCamera()

            # get the user inputs - fetch numbers by the total numbers of cases
            num = self.getRadarCameraRadioButtonStates()

            # get largest or smallest
            if self.smallest_RadioButton_2.isChecked():
                order = True
            if self.largest_RadioButton_2.isChecked():
                order = False

            # Format data for aggregation use
            self._dfRC = format_data_for_aggregation_RC(self._df)

            # Filter data by indicators
            self._dfRC = filter_data_by_indicators(self._dfRC, listIndicators)

            # Fetch data based on offence description
            self._dfRC = fetch_data_by_offence_description(self._dfRC, listRadarCamera)

            # Fetch data based on offence description contains key words
            self._dfRC = fetch_data_by_offence_description(self._dfRC, listKey)
            # ________________________________________________________________________
            # Aggregate data group by offence code
            # For a user-selected period, produce a chart to show the distribution of cases in each offence code
            # ________________________________________________________________________
            self._dfRC = aggregate_data_group_by_offence_code(self._dfRC, order, num)

            if not hasattr(self, "canvasRC"):
                self.canvasRC = MyMatplotlibFigure(width=5, height=4, dpi=100)

            self.canvasRC.mat_plot_draw_bar(self._dfRC)
            self.figureRC_HorizontalLayout.addWidget(self.canvasRC)

            time_end = time.time()

            if self._dfRC.empty:
                self.statusbar.showMessage("No records found.")
            else:
                self.statusbar.showMessage("{} records found in {:.2f} seconds".format(self._dfRC['OFFENCE_CODE'].count(), time_end - time_start))

        except Exception as e:
            # output the log file
            print(e)

    def getRadarCameraRadioButtonKeyword(self):

        if self.allRC_RadioButton.isChecked():
            listRadarCamera = ['radar', 'camera', 'Radar', 'Camera']
        elif self.radar_RadioButton.isChecked():
            listRadarCamera = ['radar', 'Radar']
        elif self.camera_RadioButton.isChecked():
            listRadarCamera = ['camera', 'Camera']
        else:
            listRadarCamera = ['radar', 'camera', 'Radar', 'Camera']

        return listRadarCamera

    def getRadarCameraCheckBoxStates(self):

        # store checkbox checked status
        listIndicators = ["0", "0", "0", "0", "0", "0"]

        # point to point camera checkbox
        if self.ptopC_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        # red light camera checkbox
        if self.redC_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        # speed camera checkbox
        if self.speedC_CheckBox.isChecked():
            listIndicators.append("1")
        else:
            listIndicators.append("0")

        listIndicators.append("0")
        listIndicators.append("0")

        return listIndicators

    def getRadarCameraRadioButtonStates(self):

        if self.all_RadioButton_2.isChecked():
            num = None
        elif self.largest_RadioButton_2.isChecked():
            num = self.largest_SpinBox_2.value()
        elif self.smallest_RadioButton_2.isChecked():
            num = self.smallest_SpinBox_2.value()
        else:
            num = None

        return num

    def getKeywordsForRadarCamera(self):

        strKeyword = self.keywords_LineEdit.text()

        listKeyword = strKeyword.split(",")

        return listKeyword

    def showDetailRC(self):

        # ________________________________________________________________________
        # bar chart diagram to illustrate the number of cases captured by radar or camera
        # X axis shows offence codes, while Y axis shows the total number of cases in each offence code
        # •	For a user-selected period, retrieve all cases captured by radar or camera based on offence description
        # ________________________________________________________________________

        # columns <==> rows
        code = pd.DataFrame(self._dfRC.values.T, columns=self._dfRC.index, index=self._dfRC.columns)
        # covert to a list
        nmpNum = code.iloc[2].to_numpy()
        nmmpId = np.arange(1, len(nmpNum) + 1)

        fig, ax = plt.subplots()
        # draw a bar chart
        ax.bar(nmmpId, nmpNum, color='green', alpha=0.7)
        # set X axis label
        ax.set_xlabel('OFFENCE')
        # set Y axis label
        ax.set_ylabel('TOTAL_NUMBER')
        # set title of the scatter diagram
        ax.set_title('The number of cases captured by radar or camera')
        # adjust diagram position
        plt.subplots_adjust(top=0.8, bottom=0.2)

        # shows a detailed information for each record
        text = []
        for i in range(self._dfRC['OFFENCE_CODE'].count()):
            # a detailed information
            str_info = 'Offence Code: ' + str(self._dfRC['OFFENCE_CODE'][i]) + '\n'
            str_info += 'Offence Description: ' + str(self._dfRC['OFFENCE_DESC'][i]) + '\n'
            str_info += 'Number of Cases: ' + str(self._dfRC['TOTAL_NUMBER'][i])
            text.append(str_info)

        # draw points with a detailed information
        self.po_annotation = []
        for i in range(self._dfRC['OFFENCE_CODE'].count()):
            point_x = i + 1
            point_y = self._dfRC['TOTAL_NUMBER'][i]
            point, = plt.plot(point_x, point_y, 'o', c='green', alpha=0.2)
            # set x axis, y axis offset for a detailed information
            xoffset = -200
            yoffset = 40
            # a box contains detailed information
            bbox = dict(boxstyle='round', fc='lightgreen', alpha=0.6)
            # set arrow style
            arrowprops = dict(arrowstyle='->', connectionstyle='arc3,rad=0.')
            # set annotate
            annotation = plt.annotate(text[i], xy=(i + 1, self._dfRC['TOTAL_NUMBER'][i]),
                                         xytext=(xoffset, yoffset),
                                         textcoords='offset points', bbox=bbox, arrowprops=arrowprops, size=10)
            # set visible
            annotation.set_visible(False)
            self.po_annotation.append([point, annotation])

        # ax.grid(True)
        fig.tight_layout()
        # bind motion event to shows detailed information for a chosen record
        fig.canvas.mpl_connect('motion_notify_event', self.on_move)
        # show the bar diagram
        plt.show()

    def drillDownByMobilePhone(self):
        """
        This is a drill down function by mobile phone
        """
        try:
            time_start = time.time()

            content = None

            # get the user inputs - mobile phone radio button
            if self.mobile_RadioButton.isChecked():
                isAll = False
            else:
                isAll = True

            if isAll == False:
                # get the user inputs - combobox
                idx = self.mobile_ComboBox.currentIndex()
                content = self.mobile_ComboBox.itemText(idx)

            # Format data for mobile phone use
            self._dfMP = format_data_for_mobile_phone(self._df)

            # Format data for aggregation use
            self._listdfMP = fetch_data_by_exactly_offence_description(self._dfMP, content, self._comboTexts)

            if not hasattr(self, "canvasMP"):
                self.canvasMP = MyMatplotlibFigure(width=5, height=4, dpi=100)

            self.canvasMP.mat_plot_draw_line(self._listdfMP)
            self.figureMP_HorizontalLayout.addWidget(self.canvasMP)

            total = 0
            for dfMP in self._listdfMP:
                total += dfMP['OFFENCE_CODE'].count()

            time_end = time.time()

            if self._dfMP.empty:
                self.statusbar.showMessage("No records found.")
            else:
                self.statusbar.showMessage(
                    "{} records found in {:.2f} seconds".format(total,
                                                                time_end - time_start))

        except Exception as e:
            # output the log file
            print(e)

    def showDetailMP(self):

        # ________________________________________________________________________
        # bar chart diagram to illustrate the number of cases captured by radar or camera
        # X axis shows offence codes, while Y axis shows the total number of cases in each offence code
        # •	For a user-selected period, retrieve all cases captured by radar or camera based on offence description
        # ________________________________________________________________________

        fig, ax = plt.subplots()

        for dfMP in self._listdfMP:
            # set a line chart
            ax.plot(dfMP['OFFENCE_MONTH'], dfMP['TOTAL_NUMBER'])

        # set X axis label
        ax.set_xlabel('OFFENCE_MONTH')
        # set Y axis label
        ax.set_ylabel('TOTAL_NUMBER')
        # set title of the scatter diagram
        ax.set_title('The trend of offence cases related to mobile phone over the period')
        # adjust diagram position
        plt.subplots_adjust(top=0.8, bottom=0.2)

        # shows a detailed information for each record
        text = []
        idx = 0
        # draw points with a detailed information
        self.po_annotation = []
        for dfMP in self._listdfMP:
            for i in range(dfMP['OFFENCE_CODE'].count()):
                # a detailed information
                str_info = 'Offence Code: ' + str(dfMP['OFFENCE_CODE'][i]) + '\n'
                str_info += 'Offence Description: ' + str(dfMP['OFFENCE_DESC'][i]) + '\n'
                str_info += 'Number of Cases: ' + str(dfMP['TOTAL_NUMBER'][i])
                text.append(str_info)

                point_x = dfMP['OFFENCE_MONTH'][i]
                point_y = dfMP['TOTAL_NUMBER'][i]
                point, = plt.plot(point_x, point_y, 'o', c='green', alpha=0.2)
                # set x axis, y axis offset for a detailed information
                xoffset = -200
                yoffset = 40
                # a box contains detailed information
                bbox = dict(boxstyle='round', fc='lightgreen', alpha=0.6)
                # set arrow style
                arrowprops = dict(arrowstyle='->', connectionstyle='arc3,rad=0.')
                # set annotate
                annotation = plt.annotate(text[idx], xy=(dfMP['OFFENCE_MONTH'][i], dfMP['TOTAL_NUMBER'][i]),
                                          xytext=(xoffset, yoffset),
                                          textcoords='offset points', bbox=bbox, arrowprops=arrowprops, size=10)
                # set visible
                annotation.set_visible(False)
                self.po_annotation.append([point, annotation])
                idx += 1

        # ax.grid(True)
        fig.tight_layout()
        # bind motion event to shows detailed information for a chosen record
        fig.canvas.mpl_connect('motion_notify_event', self.on_move)
        # show the line diagram
        plt.show()

    def clickOCCompare(self):
        if self._compareAData is None:
            self._compareAData = self._dfOC.copy()
            self._compareADataType = "OC"
            self.compareOC_PushButton.setText("Compare to")
            self.compareRC_PushButton.setText("Compare to")
            self.compareMP_PushButton.setText("Compare to")
        else:
            self._compareBData = self._dfOC.copy()
            self._compareBDataType = "OC"
            self.showCompareDiagrams()
            self.compareOC_PushButton.setText("Compare")
            self.compareRC_PushButton.setText("Compare")
            self.compareMP_PushButton.setText("Compare")
            self.cleanCompare()

    def clickRCCompare(self):
        if self._compareAData is None:
            self._compareAData = self._dfRC.copy()
            self._compareADataType = "RC"
            self.compareOC_PushButton.setText("Compare to")
            self.compareRC_PushButton.setText("Compare to")
            self.compareMP_PushButton.setText("Compare to")
        else:
            self._compareBData = self._dfRC.copy()
            self._compareBDataType = "RC"
            self.showCompareDiagrams()
            self.compareOC_PushButton.setText("Compare")
            self.compareRC_PushButton.setText("Compare")
            self.compareMP_PushButton.setText("Compare")
            self.cleanCompare()

    def clickMPCompare(self):
        if self._compareAData is None:
            self._compareAData = self._listdfMP.copy()
            self._compareADataType = "MP"
            self.compareOC_PushButton.setText("Compare to")
            self.compareRC_PushButton.setText("Compare to")
            self.compareMP_PushButton.setText("Compare to")
        else:
            self._compareBData = self._listdfMP.copy()
            self._compareBDataType = "MP"
            self.showCompareDiagrams()
            self.compareOC_PushButton.setText("Compare")
            self.compareRC_PushButton.setText("Compare")
            self.compareMP_PushButton.setText("Compare")
            self.cleanCompare()

    def cleanCompare(self):
        self._compareAData = None
        self._compareBData = None
        self._compareADataType = ""
        self._compareBDataType = ""

    def showCompareDiagrams(self):

        fig = plt.figure()
        axA, axB = fig.subplots(1, 2)
        if self._compareADataType == "OC":
            # random colors for each offence code
            colors = np.random.rand(self._compareAData['OFFENCE_CODE'].count())
            # set a scatter diagram
            axA.scatter(self._compareAData['OFFENCE_CODE'], self._compareAData['TOTAL_NUMBER'], c=colors, alpha=0.7)
            # set X axis label
            axA.set_xlabel('OFFENCE_CODE')
            # set Y axis label
            axA.set_ylabel('TOTAL_NUMBER')
            # set title of the scatter diagram
            axA.set_title('The distribution of cases in each offence code')
        elif self._compareADataType == "RC":
            # columns <==> rows
            code = pd.DataFrame(self._compareAData.values.T, columns=self._compareAData.index, index=self._compareAData.columns)
            # covert to a list
            nmpNum = code.iloc[2].to_numpy()
            nmmpId = np.arange(1, len(nmpNum) + 1)

            # draw a bar chart
            axA.bar(nmmpId, nmpNum, color='green', alpha=0.7)
            # set X axis label
            axA.set_xlabel('OFFENCE')
            # set Y axis label
            axA.set_ylabel('TOTAL_NUMBER')
            # set title of the scatter diagram
            axA.set_title('The number of cases captured by radar or camera')
        else:
            for dfMP in self._compareAData:
                # set a line chart
                axA.plot(dfMP['OFFENCE_MONTH'], dfMP['TOTAL_NUMBER'])

            # set X axis label
            axA.set_xlabel('OFFENCE_MONTH')
            # set Y axis label
            axA.set_ylabel('TOTAL_NUMBER')
            # set title of the scatter diagram
            axA.set_title('The trend of offence cases related to mobile phone over the period')

        if self._compareBDataType == "OC":
            # random colors for each offence code
            colors = np.random.rand(self._compareBData['OFFENCE_CODE'].count())
            # set a scatter diagram
            axB.scatter(self._compareBData['OFFENCE_CODE'], self._compareBData['TOTAL_NUMBER'], c=colors, alpha=0.7)
            # set X axis label
            axB.set_xlabel('OFFENCE_CODE')
            # set Y axis label
            axB.set_ylabel('TOTAL_NUMBER')
            # set title of the scatter diagram
            axB.set_title('The distribution of cases in each offence code')
        elif self._compareBDataType == "RC":
            # columns <==> rows
            code = pd.DataFrame(self._compareBData.values.T, columns=self._compareBData.index, index=self._compareBData.columns)
            # covert to a list
            nmpNum = code.iloc[2].to_numpy()
            nmmpId = np.arange(1, len(nmpNum) + 1)

            # draw a bar chart
            axB.bar(nmmpId, nmpNum, color='green', alpha=0.7)
            # set X axis label
            axB.set_xlabel('OFFENCE')
            # set Y axis label
            axB.set_ylabel('TOTAL_NUMBER')
            # set title of the scatter diagram
            axB.set_title('The number of cases captured by radar or camera')
        else:
            for dfMP in self._compareBData:
                # set a line chart
                axB.plot(dfMP['OFFENCE_MONTH'], dfMP['TOTAL_NUMBER'])

            # set X axis label
            axB.set_xlabel('OFFENCE_MONTH')
            # set Y axis label
            axB.set_ylabel('TOTAL_NUMBER')
            # set title of the scatter diagram
            axB.set_title('The trend of offence cases related to mobile phone over the period')

        # show the scatter diagram
        plt.show()
        return

    # This is motion callback function to set visible of detailed information
    def on_move(self, event):
        visibility_changed = False

        for point, annotation in self.po_annotation:
            should_be_visible = (point.contains(event)[0] == True)

            if should_be_visible != annotation.get_visible():
                visibility_changed = True
                annotation.set_visible(should_be_visible)

        if visibility_changed:
            plt.draw()




if __name__ == '__main__':
    try:
        app = QApplication(sys.argv)
        myWin = MyMainWindow()
        myWin.show()

        sys.exit(app.exec_())
    except Exception as e:
        # output the log file
        print(e)
    finally:
        if (sys):
            sys.exit(0)