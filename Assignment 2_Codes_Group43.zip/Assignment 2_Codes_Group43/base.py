# base.py
# @author Bozhao Li
# @desc This is the core code to initiate NSW Traffic Penalty Data Analysis System.
# @date 2022/09/01
import configparser
import pandas as pd

def d_parser(date):
    """
    To format datetime
    :param date
    :return format date
    """
    return pd.to_datetime(date, format='%d/%m/%Y')

def initiate():
    """
    To load system configuration attributes
    :param
    :return A dictionary contains key-value pairs for each system configuration dict<str, str>
    """
    try:
        # Load software configuration file
        config = configparser.ConfigParser()
        config.read("config.ini")

        # A dictionary contains key-value pairs for each system configuration dict<str, str>
        iniDict = {}

        # Load meta configurations
        name = config.get('meta', 'Name')
        iniDict['Name'] = name
        desc = config.get('meta', 'Description')
        iniDict['Description'] = desc
        version = config.get('meta', 'Version')
        iniDict['Version'] = version

        # Load default configurations
        filePath = config.get('default', 'OriginalFilePath')
        iniDict['OriginalFilePath'] = filePath
        fileName = config.get('default', 'OriginalFIleName')
        iniDict['OriginalFIleName'] = fileName

        # Load developers
        developers = config.get('developer', 'Name')
        iniDict['Developer'] = developers
    except:
        print("Load configuration file fails.")

    return iniDict

def load_data(filePathName):
    """
    To load original dataset file
    :param filePathName <str>
    :return all records <Dataframe>
    """
    # format float numbers
    pd.set_option('display.float_format', lambda x: '%.2f' % x)

    # read from a csv file
    dataframe = pd.read_csv(
        filePathName,
        dtype = {
                    'CAMERA_IND': 'category',
                    'SCHOOL_ZONE_IND': 'category',
                    'SPEED_IND': 'category',
                    'POINT_TO_POINT_IND': 'category',
                    'RED_LIGHT_CAMERA_IND': 'category',
                    'SPEED_CAMERA_IND': 'category',
                    'SEATBELT_IND': 'category',
                    'MOBILE_PHONE_IND': 'category',
                    'PARKING_IND': 'category',
                    'CINS_IND': 'category',
                    'FOOD_IND': 'category',
                    'BICYCLE_TOY_ETC_IND': 'category',
                }, parse_dates=['OFFENCE_MONTH'], date_parser=d_parser)

    return dataframe
