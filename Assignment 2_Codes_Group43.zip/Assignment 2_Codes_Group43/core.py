import pandas as pd
import numpy as np
from matplotlib.dates import MonthLocator, DateFormatter
import matplotlib.pyplot as plt

def format_data_for_aggregation(dataframe):
    """
        To remain 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER' columns and remove unnecessary columns
        :param dataframe：Input records <Dataframe>
        :return dataframe：Format records <Dataframe>
    """

    # Drop unnecessary columns
    dataframe = dataframe.drop(['OFFENCE_FINYEAR', 'LEGISLATION', 'SECTION_CLAUSE', 'FACE_VALUE',
                                'CAMERA_TYPE', 'LOCATION_CODE', 'LOCATION_DETAILS', 'SPEED_BAND', 'TOTAL_VALUE'], axis=1)

    return dataframe

def format_data_for_aggregation_RC(dataframe):
    """
        To remain 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER' columns and remove unnecessary columns
        :param dataframe：Input records <Dataframe>
        :return dataframe：Format records <Dataframe>
    """

    # Drop unnecessary columns
    dataframe = dataframe.drop(['OFFENCE_FINYEAR', 'LEGISLATION', 'SECTION_CLAUSE', 'FACE_VALUE',
                                'CAMERA_IND', 'CAMERA_TYPE', 'LOCATION_CODE', 'LOCATION_DETAILS', 'SCHOOL_ZONE_IND',
                                'SPEED_BAND', 'SPEED_IND', 'SEATBELT_IND', 'MOBILE_PHONE_IND', 'PARKING_IND', 'CINS_IND',
                                'FOOD_IND', 'BICYCLE_TOY_ETC_IND', 'TOTAL_VALUE'], axis=1)

    return dataframe

def format_data_for_offence_description(dataframe):
    """
        To remain 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER' columns and remove unnecessary columns
        :param dataframe：Input records <Dataframe>
        :return dataframe：Format records <Dataframe>
    """

    # Drop unnecessary columns
    dataframe = dataframe.drop(['OFFENCE_FINYEAR', 'OFFENCE_MONTH', 'LEGISLATION', 'SECTION_CLAUSE', 'FACE_VALUE',
                                'CAMERA_IND', 'CAMERA_TYPE', 'LOCATION_CODE', 'LOCATION_DETAILS', 'SCHOOL_ZONE_IND',
                                'SPEED_BAND', 'SPEED_IND', 'POINT_TO_POINT_IND', 'RED_LIGHT_CAMERA_IND',
                                'SPEED_CAMERA_IND', 'SEATBELT_IND', 'MOBILE_PHONE_IND', 'PARKING_IND', 'CINS_IND',
                                'FOOD_IND', 'BICYCLE_TOY_ETC_IND', 'TOTAL_VALUE'], axis=1)

    return dataframe

def format_data_for_mobile_phone(dataframe):
    """
        To remain 'OFFENCE_CODE', 'OFFENCE_DESC', 'OFFENCE_MONTH', 'TOTAL_NUMBER' columns and remove unnecessary columns
        :param dataframe：Input records <Dataframe>
        :return dataframe：Format records <Dataframe>
    """
    dataframe = dataframe[(dataframe['MOBILE_PHONE_IND'] == "Y")]

    # Drop unnecessary columns
    dataframe = dataframe.drop(['OFFENCE_FINYEAR', 'LEGISLATION', 'SECTION_CLAUSE', 'FACE_VALUE',
                                'CAMERA_IND', 'CAMERA_TYPE', 'LOCATION_CODE', 'LOCATION_DETAILS', 'SCHOOL_ZONE_IND',
                                'SPEED_BAND', 'SPEED_IND', 'POINT_TO_POINT_IND', 'RED_LIGHT_CAMERA_IND',
                                'SPEED_CAMERA_IND', 'SEATBELT_IND', 'MOBILE_PHONE_IND', 'PARKING_IND', 'CINS_IND',
                                'FOOD_IND', 'BICYCLE_TOY_ETC_IND', 'TOTAL_VALUE'], axis=1)

    return dataframe

def check_and_clean_data(dataframe):
    """
    1. To check the dataframe
    2. To remove the invalid data
    :param dataframe：Original records <Dataframe>
    :return dataframe：Cleaned records <Dataframe>
    """

    # Check key columns: OFFENCE_FINYEAR, OFFENCE_MONTH, OFFENCE_CODE, OFFENCE_DESC, LEGISLATION, SECTION_CLAUSE, FACE_VALUE, TOTAL_NUMBER, TOTAL_VALUE
    dataframe = dataframe.dropna(axis='index', how='any', subset=['OFFENCE_FINYEAR', 'OFFENCE_MONTH', 'OFFENCE_CODE',
                                                                  'OFFENCE_DESC', 'LEGISLATION', 'SECTION_CLAUSE',
                                                                  'FACE_VALUE', 'TOTAL_NUMBER', 'TOTAL_VALUE'])

    # Check related columns:

    # Remove duplicated rows
    dataframe = dataframe.drop_duplicates()

    # Check validation:

    # Sort data by offence_month asc, offence_code asc
    dataframe = dataframe.sort_values(by=['OFFENCE_MONTH', 'OFFENCE_CODE'], ascending=[True, True], ignore_index=True)

    return dataframe

def fetch_data_by_date(dataframe, startDate, endDate):
    """
        To fetch dataframe between startDate <Date> and endDate <Date>
        :param Original records <Dataframe>
        :return Selected records <Dataframe>
    """

    # fetch records in the selected time period
    dataframe = dataframe[(dataframe['OFFENCE_MONTH'] >= startDate) & (dataframe['OFFENCE_MONTH'] <= endDate)]

    return dataframe

def aggregate_data_group_by_offence_code(dataframe, order, total):
    """
        To sum up 'TOTAL_NUMBER' group by 'OFFENCE_CODE'
        :param Original records <Dataframe>
        :param order <bool> Ture: ascending order False: descending order
        :return Aggregated records <Dataframe>
    """

    if (total == None):
        total = dataframe.shape[0]

    # Aggregate the total number of cases for each offence code
    dataframe = dataframe.groupby(['OFFENCE_CODE', 'OFFENCE_DESC'], as_index=False).sum()

    # Sort data by total number desc
    dataframe = dataframe.sort_values(by='TOTAL_NUMBER', ascending=order, ignore_index=True)[:total]

    return dataframe

def filter_data_by_indicators(dataframe, listIndicators):
    """
        To filter data by indicators
        :param Original records <Dataframe>
        :param List of indicators <list>
        :return Search result records <Dataframe>
    """

    # set an empty dataframe for further checks
    df1 = pd.DataFrame(data=None, columns=['OFFENCE_MONTH', 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER'])

    # seat belt indicator selected
    if listIndicators[0] == "1":
        df1 = dataframe[(dataframe['SEATBELT_IND'] == "Y")]

    # speed indicator selected
    if listIndicators[1] == "1":
        df2 = dataframe[(dataframe['SPEED_IND'] == "Y")]
        if df1.empty:
            df1 = df2
        else:
            df1 = pd.merge(df1, df2, on=['OFFENCE_MONTH', 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER'], how='outer')

    # parking indicator selected
    if listIndicators[2] == "1":
        df2 = dataframe[(dataframe['PARKING_IND'] == "Y")]
        if df1.empty:
            df1 = df2
        else:
            df1 = pd.merge(df1, df2, on=['OFFENCE_MONTH', 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER'], how='outer')

    # school zone indicator selected
    if listIndicators[3] == "1":
        df2 = dataframe[(dataframe['SCHOOL_ZONE_IND'] == "Y")]
        if df1.empty:
            df1 = df2
        else:
            df1 = pd.merge(df1, df2, on=['OFFENCE_MONTH', 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER'], how='outer')

    # mobile phone indicator selected
    if listIndicators[4] == "1":
        df2 = dataframe[(dataframe['MOBILE_PHONE_IND'] == "Y")]
        if df1.empty:
            df1 = df2
        else:
            df1 = pd.merge(df1, df2, on=['OFFENCE_MONTH', 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER'], how='outer')

    # food safety indicator selected
    if listIndicators[5] == "1":
        df2 = dataframe[(dataframe['FOOD_IND'] == "Y")]
        if df1.empty:
            df1 = df2
        else:
            df1 = pd.merge(df1, df2, on=['OFFENCE_MONTH', 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER'], how='outer')

    # point to point camera indicator selected
    if listIndicators[6] == "1":
        df2 = dataframe[(dataframe['POINT_TO_POINT_IND'] == "Y")]
        if df1.empty:
            df1 = df2
        else:
            df1 = pd.merge(df1, df2, on=['OFFENCE_MONTH', 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER'], how='outer')

    # red light camera indicator selected
    if listIndicators[7] == "1":
        df2 = dataframe[(dataframe['RED_LIGHT_CAMERA_IND'] == "Y")]
        if df1.empty:
            df1 = df2
        else:
            df1 = pd.merge(df1, df2, on=['OFFENCE_MONTH', 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER'], how='outer')

    # speed camera indicator selected
    if listIndicators[8] == "1":
        df2 = dataframe[(dataframe['SPEED_CAMERA_IND'] == "Y")]
        if df1.empty:
            df1 = df2
        else:
            df1 = pd.merge(df1, df2, on=['OFFENCE_MONTH', 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER'], how='outer')

    # criminal infringement notice scheme indicator selected
    if listIndicators[9] == "1":
        df2 = dataframe[(dataframe['CINS_IND'] == "Y")]
        if df1.empty:
            df1 = df2
        else:
            df1 = pd.merge(df1, df2, on=['OFFENCE_MONTH', 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER'], how='outer')

    # bicycle, wheeled toy and other non-Motor vehicle indicator selected
    if listIndicators[10] == "1":
        df2 = dataframe[(dataframe['BICYCLE_TOY_ETC_IND'] == "Y")]
        if df1.empty:
            df1 = df2
        else:
            df1 = pd.merge(df1, df2, on=['OFFENCE_MONTH', 'OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER'], how='outer')

    # no checkbox is selected
    if df1.empty:
        # return the input dataframe
        return dataframe[['OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER']]
    else:
        # return the merged dataframe
        return df1[['OFFENCE_CODE', 'OFFENCE_DESC', 'TOTAL_NUMBER']]

def fetch_data_by_offence_description(dataframe, listKey):
    """
        To fetch records by radar or camera based on offence description
        :param Original records <Dataframe>
        :param Conditions list<str>
        :return Selected records <Dataframe>
    """

    # condition
    strKey = ""
    flag = False

    # create condition based on listKey
    for key in listKey:
        if flag == True:
            strKey += " | " + key
        else:
            strKey += key
            flag = True

    # fetch data by offence description which contains key words
    dataframe = dataframe[dataframe['OFFENCE_DESC'].str.contains(strKey)]

    return dataframe

def getMobilePhoneAllOffences(dataframe):
    """
        To fetch all offence order and descriptions by mobile phone (mobile phone indicator = "Y")
        :param Original records <Dataframe>
        :return Selected records <Dataframe>
    """
    dataframe = dataframe[(dataframe['MOBILE_PHONE_IND'] == "Y")]['OFFENCE_DESC'].unique()

    # if dataframe.empty:
    #     return None
    # else:
    #     # Aggregate the total number of cases for each offence code
    #     dataframe = dataframe.groupby(['OFFENCE_CODE', 'OFFENCE_DESC'], as_index=False).sum()
    #
    #     # return the dataframe
    #     return dataframe['OFFENCE_DESC']

    return dataframe

def fetch_data_by_exactly_offence_description(dataframe, content, listMobileDescription):
    """
        To fetch records by offence description
        :param Original records <Dataframe>
        :param content <str>
        :return Selected records <Dataframe>
    """
    arrayDataframe = []

    if content == None:
        for mobileDescription in listMobileDescription:
            # fetch data by offence description which contains key words
            dfTemp = dataframe.loc[dataframe['OFFENCE_DESC'] == mobileDescription]
            dfTemp = dfTemp.sort_values(by='OFFENCE_MONTH', ascending=True, ignore_index=True)
            arrayDataframe.append(dfTemp)
    else:
        # fetch data by offence description which contains key words
        dfTemp = dataframe.loc[dataframe['OFFENCE_DESC'] == content]
        dfTemp = dfTemp.sort_values(by='OFFENCE_MONTH', ascending=True, ignore_index=True)
        arrayDataframe.append(dfTemp)

    return arrayDataframe