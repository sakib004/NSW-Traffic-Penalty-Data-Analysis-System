import core
import base

def check_filter_data_by_indicators(dataframe, listIndicators):
    return core.filter_data_by_indicators(dataframe, listIndicators)

def check_format_data_for_aggregation(dataframe):
    return core.format_data_for_aggregation(dataframe)

def check_format_data_for_aggregation_RC(dataframe):
    return core.format_data_for_aggregation_RC(dataframe)

def check_format_data_for_offence_description(dataframe):
    return core.format_data_for_offence_description(dataframe)

def check_format_data_for_mobile_phone(dataframe):
    return core.format_data_for_mobile_phone(dataframe)

def check_check_and_clean_data(dataframe):
    return core.check_and_clean_data(dataframe)

def check_fetch_data_by_date(dataframe, startDate, endDate):
    return core.fetch_data_by_date(dataframe, startDate, endDate)

def check_aggregate_data_group_by_offence_code(dataframe, order, total):
    return core.aggregate_data_group_by_offence_code(dataframe, order, total)

def check_fetch_data_by_offence_description(dataframe, listKey):
    return core.fetch_data_by_offence_description(dataframe, listKey)

def check_getMobilePhoneAllOffences(dataframe):
    return core.getMobilePhoneAllOffences(dataframe)

def check_fetch_data_by_exactly_offence_description(dataframe, content, listMobileDescription):
    return core.fetch_data_by_exactly_offence_description(dataframe, content, listMobileDescription)

dataframe = base.load_data('origin\data.csv')
print(check_format_data_for_aggregation(dataframe))

print(check_format_data_for_aggregation_RC(dataframe))

print(check_format_data_for_offence_description(dataframe))

print(check_format_data_for_mobile_phone(dataframe))

print(check_check_and_clean_data(dataframe))

print(check_fetch_data_by_date(dataframe, "01-02-2021", "01-06-2023"))


print(check_aggregate_data_group_by_offence_code(dataframe, True, None))

print(check_aggregate_data_group_by_offence_code(dataframe, False, None))

print(check_aggregate_data_group_by_offence_code(dataframe, True, 10))

print(check_aggregate_data_group_by_offence_code(dataframe, False, 10))

print(check_fetch_data_by_offence_description(dataframe, ["school"]))

print(check_fetch_data_by_offence_description(dataframe, ["school", "zone", "speed"]))

print(check_getMobilePhoneAllOffences(dataframe))

print(check_fetch_data_by_exactly_offence_description(dataframe, None, ["test1", "test2"]))

print(check_fetch_data_by_exactly_offence_description(dataframe, "test1", ["test1", "test2"]))


listIndicator = ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
listIndicator = ["1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
listIndicator = ["0", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
listIndicator = ["0", "0", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
listIndicator = ["0", "0", "0", "1", "1", "1", "1", "1", "1", "1", "1", "1"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
listIndicator = ["0", "0", "0", "0", "1", "1", "1", "1", "1", "1", "1", "1"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
listIndicator = ["0", "0", "0", "0", "0", "1", "1", "1", "1", "1", "1", "1"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
listIndicator = ["0", "0", "0", "0", "0", "0", "1", "1", "1", "1", "1", "1"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
listIndicator = ["0", "0", "0", "0", "0", "0", "0", "1", "1", "1", "1", "1"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
listIndicator = ["0", "0", "0", "0", "0", "0", "0", "0", "1", "1", "1", "1"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
listIndicator = ["0", "0", "0", "0", "0", "0", "0", "0", "0", "1", "1", "1"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
listIndicator = ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "1", "1"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
listIndicator = ["0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "1"]
print(check_filter_data_by_indicators(dataframe, listIndicator))
