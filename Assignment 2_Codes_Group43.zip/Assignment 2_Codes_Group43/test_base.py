import base
import os
from datetime import datetime

def test_base_d_parser():
    result = base.d_parser(datetime(2012, 2, 10, 0, 0, 0))
    print(datetime(2012, 2, 10, 0, 0, 0))

def test_base_initiate():
    base.initiate()

def test_base_loadcsv():
    dataframe = base.load_data('origin\data.csv')

test_base_d_parser()
test_base_initiate()
test_base_loadcsv()
try:
    os.rename("config.ini", 'config01.ini')
    test_base_initiate()
except:
    print("ok")
